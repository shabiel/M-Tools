package gov.va.med.foundations.adapter.record;

/**
 * 
 * Request factory interface to be used to construct request objects.
 * 
 * @author Application Modernization - Foundations Team
 * @version 1.0.0.193
 */
public interface VistaLinkRequestFactory {

}
