/*
 * Created on Apr 20, 2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package gov.va.med.iss.meditor.utils;

/**
 * @author vhaisfiveyj
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public interface IMTypes {
	
	public static final int TAG = 0;
	public static final int COMMAND = 1;
	public static final int VARIABLE = 2;
	public static final int FUNCTION = 3;
	public static final int VARSEEN = 4;

}
