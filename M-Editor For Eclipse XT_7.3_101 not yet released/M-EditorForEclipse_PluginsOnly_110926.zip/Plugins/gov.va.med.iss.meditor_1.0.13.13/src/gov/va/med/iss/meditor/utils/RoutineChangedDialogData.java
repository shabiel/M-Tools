package gov.va.med.iss.meditor.utils;

public class RoutineChangedDialogData {
	
	private boolean saveServerRoutine = false;
	private boolean returnValue = false;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void setSaveServerRoutine(boolean value) {
		saveServerRoutine = value;
	}
	
	public boolean getSaveServerRoutine() {
		return saveServerRoutine;
	}
	
	public void setReturnValue(boolean value) {
		returnValue = value;
	}
	
	public boolean getReturnValue() {
		return returnValue;
	}

}
