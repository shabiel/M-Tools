/*
 * Created on Mar 10, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package gov.va.med.foundations.security.vistalink;

/**
 * @author vhaisfiveyj
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CurrentIpAndPort {
	
	private String ipVal;
	private String portVal;
	
	public String getIp() {
		return ipVal;
	}
	
	public void setIp(String ip) {
		ipVal = ip;
	}
	
	public String getPort() {
		return portVal;
	}
	
	public void setPort(String port) {
		portVal = port;
	}

}
